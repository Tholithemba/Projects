#include "testcase.h"
#include "read_data_file.h"
#include <fstream>
#include<string>


std::string testcase::sp_strArraytest(std::string* &str_sp)
{
	int size = 10;
	std::string* test_sp_str;
	test_sp_str = new std::string[size];
	
	orig_array(test_sp_str);

	int r;

	for(r = 0; r < size; r++)
	 if(str_sp[r] != test_sp_str[r] )
	 	return "case 2 failed";
	 	
	return "case 2 passed";
}

std::string testcase::runing_totalstest(int sum, int num)
{
	switch(num)
	{
		case 1: if(sum == 168) return "case 1 passed";
						else return "case 1 failed";
		break;
		
		case 2: if(sum == 187) return "case 1 passed";
						else return "case 1 failed";
		break;
		
		case 3: if(sum == 149) return "case 1 passed";
						else return "case 1 failed";
		break;
		
		default : "wrong value";
	}
}

void testcase::orig_array(std::string* &test_sp_str)
{
	int size = 10;
	int r = 0;
	read_data_file rf;
	
	for(r = 0; r < size; r++)
		test_sp_str[r] = rf.spare_strike[r];	
}

