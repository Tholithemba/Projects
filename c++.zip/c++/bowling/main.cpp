#include "bowling.h"


//execution starts here
int main()
{
	bowling b;
	b.list();//calling list method in bowling class

	return 0;
}
