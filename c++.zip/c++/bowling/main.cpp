#include "sparestrike.h"
#include "testcase.h"
#include<iostream>
#include<fstream>
#include<iomanip>

using namespace std;

void initialising_arrays(int* &frame);
void print_Results(int* &frame, sparestrike ss);
void runn_testcases(int* &frame, testcase tc, sparestrike ss);

int main()
{
	int* frame;
	
	frame = new int[10];
	const int arr1[17] = {10,7,3,7,2,9,1,10,10,10,2,3,6,4,7,3,3};
	const int arr2[17] = {10,9,1,5,5,7,2,10,10,10,9,0,8,2,9,1,10};
	const int arr3[19] = {8,2,5,4,9,0,10,10,5,5,5,3,6,3,9,1,9,1,10};
	int sizeof_arr1 = 17;
	int sizeof_arr2 = 17;
	int sizeof_arr3 = 19;
	
  initialising_arrays(frame);

	int frame_number = 0;
	sparestrike ss;
	testcase tc;
	
	ss.set_score(arr1, sizeof_arr1);
	
	while(frame_number < 9)
	{
		ss.update_current_frames(frame, frame_number);
		frame_number++;
	}

	ss.last_frame(frame, frame_number);
	
	print_Results(frame, ss);
	
	cout<<endl;
	
	runn_testcases(frame, tc, ss);

	return 0;
}
//end of main function


//initialising frame and spare_strikeFrame arrays
void initialising_arrays(int* &frame)
{
	for(int i = 0; i < 10; i++)
				frame[i] += 0;
}

void print_Results(int* &frame, sparestrike ss)
{
	int f;
	cout<<"Frame number:     ";
	for(f = 1; f <= 10; f++)
		cout<<f<<right<<setw(8);
	cout<<endl;
	
	
	cout<<"Frame score:     ";
	for(f = 0; f < 10; f++)
		cout<<frame[f]<<setw(8);
	cout<<endl;
	
	int sum = 0;
	cout<<"Running totals:  ";
	for(f = 0; f < 10; f++)
	{
		sum += frame[f];
		cout<<sum<<setw(8);
	}
	cout<<endl;
	
	cout<<"Strike/Spare:  ";
	for(f = 0; f < 10; f++)
		cout<<ss.spare_strikeFrame[f]<<"   ";
	cout<<endl;
}

void runn_testcases(int* &frame, testcase tc, sparestrike ss)
{
	string test_case_result;
	string green_color = "\033[1;32m";
	int f, sum = 0, num = 1;
	
	for(f = 0; f < 10; f++)
		sum += frame[f];
		
	cout<<green_color<<"Test cases"<<endl;	
	test_case_result = tc.runing_totalstest(sum, num);
	cout<<test_case_result<<endl;
	
	test_case_result = tc.sp_strArraytest(ss.spare_strikeFrame);
	cout<<test_case_result<<endl;
}
