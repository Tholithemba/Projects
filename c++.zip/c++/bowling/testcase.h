#ifndef TESTCASE_H
#define TESTCASE_H
#include <string>

class testcase
{
	public:
				std::string sp_strArraytest(std::string* &str_sp);
				std::string runing_totalstest(int sum, int num);
				
	private:
				void orig_array(std::string* &arr);
};

#include "testcase.cpp"
#endif
