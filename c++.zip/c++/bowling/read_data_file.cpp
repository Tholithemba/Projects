#include "read_data_file.h"
#include <fstream>
#include <iostream>

read_data_file::read_data_file()
{
	input_file();
}

void read_data_file::input_file()
{
	std::ifstream input;
	int size = 10;
	spare_strike = new std::string[size];
	std::string line;
	
	input.open("./arrayfiles/arr1.txt");
	
	if(!input)
	{
		std::cerr<<"file failed to open"<<std::endl;
		exit(1);
	}
	int count = 0;
	while(getline(input, line))
	{
		spare_strike[count] = line;
		count++;
	}
	input.close();
}
