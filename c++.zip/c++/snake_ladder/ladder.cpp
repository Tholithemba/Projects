#include "ladder.h"
#include<iostream>

ladder::ladder()
{
	playerOne_currPos = 0;
	playerTwo_currPos = 0;
	climbOrdown = 0;
}


void ladder::play()
{
	bool player_1 = true;
	bool player_2 = false;
	bool maxPos = reachMaximumPos();
	
	while(!maxPos)
	{
		roll_dice(player_1, player_2);
		//next_player(player_1, player_2);
	    maxPos = reachMaximumPos();   
	}
	
	game_over();
}

bool ladder::check_number(int rand_number)
{
	bool climb_drop = false;
	int r;
	
	for(r = 0; r < size; r++)
	{
		if(rand_number == climb[r])
		{
			climb_drop = true;
			climb_ladder(rand_number);
		}
	}
 
	if(!climb_drop)
	{
		 for(r = 0; r < size; r++)
		 {
		 	if(rand_number == drop[r])
		 	{
		 		climb_drop = true;
		 		bite(rand_number);
		 	}
		 }
	}
	
	return 	climb_drop;		
}

void ladder::climb_ladder(int rand_number)
{
	int moveUp_to = 0;

	switch(rand_number)
	{
		case  4: moveUp_to = 14;
		break;

		case  9: moveUp_to = 31;
		break;

		case 20: moveUp_to = 38;
		break;

		case 28: moveUp_to = 84;
		break;

		case 40: moveUp_to = 59;
		break;

		case 51: moveUp_to = 67;
		break;

		case 63: moveUp_to = 81;
		break;

		case 71: moveUp_to = 91;
		break;

		default:
		   std::cout<<"Invalid position \n";	 
	}
	climbOrdown = moveUp_to;
	std::cout<<"Player moved up to position: "<< moveUp_to<<std::endl;
}

void ladder::bite(int rand_number)
{
	int moveDown_to = 0;

	switch(rand_number)
	{
		case 17: moveDown_to =  7;
		break;

		case 54: moveDown_to = 34;
		break;

		case 62: moveDown_to = 19;
		break;

		case 64: moveDown_to = 60;
		break;

		case 87: moveDown_to = 24;
		break;

		case 93: moveDown_to = 73;
		break;

		case 95: moveDown_to = 75;
		break;

		case 99: moveDown_to = 78;
		break;

		default:
		   std::cout<<"Invalid position \n";	 
	}
	climbOrdown = moveDown_to;
	std::cout<<"Player moved down to position: "<< moveDown_to<<std::endl;
}

void ladder::roll_dice(bool &player_1, bool &player_2)
{
	int roll_number = random_numbers();
	
	if(player_1)
	{
		if(player_1Active != 0)
		{
			active_player(roll_number, player_1);	
		}
		else if(player_1Active == 0 and roll_number != 6)
		{
			std::cout<<"Player 1 inactive | roll number: "<<roll_number<<std::endl;
			//next_player(player_1, player_2);
		}
		else if(player_1Active == 0 and roll_number == 6)
		{
			std::cout<<"Player 1 Active | roll number: "<<roll_number<<std::endl;
			player_1Active++;
		}
	}
	else
	{
		if(player_2Active != 0)
		{
			active_player(roll_number, player_1);	
		}
		else if(player_2Active == 0 and roll_number != 6)
		{
			std::cout<<"Player 2 inactive | roll number: "<<roll_number<<std::endl;
			//next_player(player_1, player_2);
		}
		else if(player_2Active == 0 and roll_number == 6)
		{
			std::cout<<"Player 2 Active | roll number: "<<roll_number<<std::endl;
			player_2Active++;
		}
	}
	next_player(player_1, player_2, roll_number);
}

int ladder::temp_update(int roll_number, bool player_1)
{
	int new_position = roll_number;
	
	if(player_1)
		new_position += playerOne_currPos;
	else
		new_position += playerTwo_currPos;
	
	return new_position;
}

void ladder::next_player(bool &player_1, bool &player_2, int roll_number)
{
	if(player_1 and roll_number != 6)
	{
		 player_1 = false;
		 player_2 = true;
	}
	else if(player_2 and roll_number != 6)
	{
		 player_1 = true;
		 player_2 = false;	
	}
	else if(player_1 and roll_number == 6)
	{
		 player_1 = true;
		 player_2 = false;
		 std::cout<<"Player 1 reapeat: "<<"Roll number: "<<roll_number<<std::endl;
	}
	else if(player_2 and roll_number == 6)
	{
		 player_1 = false;
		 player_2 = true;
		 std::cout<<"Player 2 reapeat: "<<"Roll number: "<<roll_number<<std::endl;
	}
}

void ladder::updatePlayer_pos(bool check_exist, int roll_number, bool player_1)
{
 	if(!check_exist)
	{
	  if(player_1)
	  {
	  	playerOne_currPos += roll_number;
	  	if(playerOne_currPos > Max_position)
	  		playerOne_currPos -= roll_number;
	  		
	  	std::cout<<"Player 1 position: "<< playerOne_currPos<<" roll number: "<<roll_number<<std::endl;
	  }
	  else
	  {
	  	playerTwo_currPos += roll_number;
	  	if(playerTwo_currPos > Max_position)
	  		playerTwo_currPos -= roll_number;
	  		
	  	std::cout<<"Player 2 position: "<< playerTwo_currPos<<" roll number: "<<roll_number<<std::endl;
	  }
	}
	else
	{
	  if(player_1)
	  {
	  	playerOne_currPos = climbOrdown;
	  	std::cout<<"Player 1 position: "<< playerOne_currPos<<" roll number: "<<roll_number<<std::endl;
	  }
	  else
	  {
	  	playerTwo_currPos = climbOrdown;
	  	std::cout<<"Player 2 position: "<< playerTwo_currPos<<" roll number: "<<roll_number<<std::endl;
	  }	
	}
}


int ladder::ladder::random_numbers()
{
	return (rand() % 6) +1;
}

void ladder::game_over()
{
	if(playerOne_currPos == Max_position)
		std::cout<<"Player 1 won !!!! \n";
	else if(playerTwo_currPos == Max_position)
		std::cout<<"Player 2 won !!!! \n";
	else
		std::cout<<"error occurred \n";
}

bool ladder::reachMaximumPos()
{
	bool stop = false;
	if(playerOne_currPos == Max_position)
		stop = true;
	else if(playerTwo_currPos == Max_position)
		stop = true;
		
	return stop;
}

void ladder::active_player(int roll_number, bool player_1)
{
	int new_position = temp_update(roll_number, player_1);
	
	bool check_exist = check_number(new_position);
	
	updatePlayer_pos(check_exist, roll_number, player_1);	
}

