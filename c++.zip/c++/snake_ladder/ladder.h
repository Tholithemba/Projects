#ifndef LADDER_H
#define LADDER_H

class ladder
{
 public:
 	ladder();
 	void play();
	int random_numbers();
 
 
 private:
	void climb_ladder(int rand_number);
	void bite(int rand_number);
	bool check_number(int rand_number);
	void roll_dice(bool &player_1, bool &player_2);
	void next_player(bool &player_1, bool &player_2, int roll_number);
	void updatePlayer_pos(bool check_exist, int roll_number, bool player_1);
	void active_player(int roll_number, bool player_1);
	int temp_update(int roll_number, bool player_1);
	bool reachMaximumPos();
	void game_over();
	
	int playerOne_currPos;
    int playerTwo_currPos;
    const int Max_position = 100;
	const int size = 8;
	const int climb[8] = {4,9,20,28,40,51,63,71};
	const int drop[8] = {17,54,62,64,87,93,95,99};
	int climbOrdown;
	int player_1Active = 0;
	int player_2Active = 0;
 			
};
#include "ladder.cpp"
#endif
