#include "ladder.h"
#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;


int main()
{
 	srand(time(0));
 	
 	ladder la;
 	
    la.play();
  /*if(random_numbers()==6)
  		la.play();*/
	cout<<"\n";
	return 0;
}


