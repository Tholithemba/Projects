#include "algorthm1.h"
#include "game.h"

int main()
{
	game g;
	g.start();

  return 0;
}








