#include "readFile.h"
#include "randomSpace.h"
#include "algorthm2.h"
#include "algorthm1.h"
#include<iostream>
#include<string>
#include<vector>

typedef std::vector<std::pair<int,int>> pair_intv;
pair_intv spaces;
pair_intv path;
int rowcol_size;
bool alg1_avail_move;
bool alg2_avail_move;
char** puzzle;

game::game()
{
}

void game::boolVariableInitialised()
{
	algorthm_1 = true;
	algorthm_2 = false;
	alg1_avail_move = true;
	alg2_avail_move = true;
}

void game::empty_spots(int center_spaces)
{  
	int row;
	int col;
	for(int row = center_spaces-2; row < center_spaces +2; row++)
		for(int col = center_spaces-2; col < center_spaces +2; col++)
		  	if(puzzle[row][col] == 'e')	  	
		  		spaces.push_back(std::make_pair(row, col));

}

int game::init_matrix()
{
	int row;
	int col;
	puzzle = new char*[rowcol_size];
	
	for(row = 0; row< rowcol_size; row++)
		puzzle[row] = new char[rowcol_size];
	
	for(row = 0; row< rowcol_size; row++)
		for(col = 0; col<rowcol_size; col++)
			puzzle[row][col] = 'e';

	return rowcol_size/2;
}


//initialising center 4 spaces with white and black color
void game::centreInit(int &center_spaces)
{
	puzzle[center_spaces-1][center_spaces-1] = 'w';
	puzzle[center_spaces-1][center_spaces] = 'b'; 
	puzzle[center_spaces][center_spaces-1] = 'b';
	puzzle[center_spaces][center_spaces] = 'w';
}

void game::start()
{
	readFile rf;
	std::vector<int> board_sizes(rf.read_file());
	int size = board_sizes.size();
	
	for(int r = 0; r < size; r++)
	{
		
		rowcol_size = board_sizes[r];
		std::cout<<"************************* "<<rowcol_size<<"x"<<rowcol_size<<" puzzle *************************"<<"\n";
		int center_spaces = init_matrix();
		centreInit(center_spaces);
		empty_spots(center_spaces);
		boolVariableInitialised();
		play();
		results();
	}
}

void game::play()
{
	
	algorthm1 alg_1;
	algorthm2 alg_2;
	int count = 0;
	
	while(!spaces.empty())
	{
		
		if(!alg1MovesAvail() and !alg2MovesAvail())return;
		path.clear();
		printCurrentBoard();
		EmptySpacesSize();
		
		if(algorthm_1)
		{
			std::cout<<"*******************************algorthm 1 turn********************************* \n";
			alg_1.setPosition();
			algorthm_1 = false;
			algorthm_2 = true;
		}
		else
		{
			std::cout<<"*******************************algorthm 2 turn********************************* \n";
			alg_2.getPosition();
			algorthm_1 = true;
			algorthm_2 = false;
		}
		std::cout<<"space size: "<<spaces.size()<<"\n";
		count++;
	}
	
	printCurrentBoard();
}

std::vector<std::pair<int,int>> game::getEmptyspaces()
{
	return spaces;
}

int game::EmptySpacesSize()
{
	return spaces.size();
}

int game::pathSize()
{
	return path.size();
}

void game::clearPath()
{
	path.clear();
}

void game::removeUsedSpace(int pos)
{
	pair_intv tem;
			
	newEmptySpaces(pos, tem);
	removeExistingPos(tem);
	spaces.erase(spaces.begin()+pos);
	addSpaces(tem);
}

void game::newEmptySpaces(int pos, pair_intv &tem)
{
	int row = spaces[pos].first;
	int col = spaces[pos].second;
		
	if(puzzleWall(row+1, col))
		if(puzzle[row+1][col] == 'e')
			tem.push_back(std::make_pair(row+1,col));
	
	if(puzzleWall(row-1, col))
		if(puzzle[row-1][col] == 'e')
			tem.push_back(std::make_pair(row-1,col));

	if(puzzleWall(row, col-1))
		if(puzzle[row][col-1] == 'e')
			tem.push_back(std::make_pair(row,col-1));
		
	if(puzzleWall(row, col+1))
		if(puzzle[row][col+1] == 'e')
			tem.push_back(std::make_pair(row,col+1));
		
	if(puzzleWall(row+1, col-1))
		if(puzzle[row+1][col-1] == 'e')
			tem.push_back(std::make_pair(row+1,col-1));
		
	if(puzzleWall(row-1, col-1))
		if(puzzle[row-1][col-1] == 'e')
			tem.push_back(std::make_pair(row-1,col-1));
		
	if(puzzleWall(row+1, col+1))
		if(puzzle[row+1][col+1] == 'e')
			tem.push_back(std::make_pair(row+1,col+1));
		
	if(puzzleWall(row-1, col+1))
		if(puzzle[row-1][col+1] == 'e')
			tem.push_back(std::make_pair(row-1,col+1));
}

void game::removeExistingPos(pair_intv &tem)
{
	for(int r = 0; r < tem.size(); )
	{
		int size = spaces.size();
		bool removed = false;
		for(int c = 0; c< size; c++)
		{
			if(tem[r].first == spaces[c].first 
			and tem[r].second == spaces[c].second)
			{
				tem.erase(tem.begin()+r);
				removed = true;
			}
		}
		
		if(removed)r=0;
		else r++;
	}		
}

void game::addSpaces(pair_intv temp)
{
	int size = temp.size();
	for(int r = 0; r < size; r++)
		spaces.push_back(temp[r]);
}

void game::fillFirstPos(int pos)
{
	int row = spaces[pos].first;
	int col = spaces[pos].second;
	
	path.push_back(std::make_pair(row,col));
}

int game::corrPosition(std::pair<int,int> temp)
{
	int size = spaces.size();
	for(int r = 0; r < size; r++)
	{
		if(temp.first == spaces[r].first and temp.second == spaces[r].second)
			return r;
	}
	return -1;
}

void game::alg1MovesAvail(bool move)
{
	alg1_avail_move = move;
}

void game::alg2MovesAvail(bool move)
{
	alg2_avail_move = move;
}

bool game::alg1MovesAvail()
{
	return alg1_avail_move;
}

bool game::alg2MovesAvail()
{
	return alg2_avail_move;
}

bool game::puzzleWall(int row, int col)
{
	return (row >= 0 and row < rowcol_size 
		and col >= 0 and col < rowcol_size);
}

bool game::down(int pos, pair_char piece)
{
	int row = spaces[pos].first;
	int col = spaces[pos].second;
	bool inside = puzzleWall(row+1, col);
	pair_intv temp;
	
	while(inside == true)
	{
		if(puzzle[row+1][col] != piece.first)break;
		
		temp.push_back(std::make_pair(row+1, col));
		row++;
		inside = puzzleWall(row+1, col);
	}

	if(inside == true)
	{
		if(puzzle[row+1][col] == piece.second and !temp.empty())
		{
			int temp_size = temp.size();
			for(int r = 0; r < temp_size; r++)
				path.push_back(temp[r]);
							
			return true;
		}
	}
	
	return false;
}


bool game::up(int pos, pair_char piece)
{
	int row = spaces[pos].first;
	int col = spaces[pos].second;
	pair_intv temp;
	bool inside = puzzleWall(row-1, col);
	
	while(inside == true)
	{
		if(puzzle[row-1][col] != piece.first)break;
		
		temp.push_back(std::make_pair(row-1, col));
		row--;
		
		inside = puzzleWall(row-1, col);
	}
	
	if(inside == true)
	{
		
		
		if(puzzle[row-1][col] == piece.second and !temp.empty())
		{
			int temp_size = temp.size();
			for(int r = 0; r < temp_size; r++)
				path.push_back(temp[r]);
					
			return true;
		}
	}
	
	return false;
}

bool game::left(int pos, pair_char piece)
{
	int row = spaces[pos].first;
	int col = spaces[pos].second;
	pair_intv temp;
	bool inside = puzzleWall(row, col-1);
	
	while(inside == true )
	{
		if(puzzle[row][col-1] != piece.first)break;
		
		temp.push_back(std::make_pair(row, col-1));
		col--;
		inside = puzzleWall(row, col-1);
	}
	
	if(inside == true)
	{
		if(puzzle[row][col-1] == piece.second and !temp.empty())
		{
			int temp_size = temp.size();
			for(int r = 0; r < temp_size; r++)
				path.push_back(temp[r]);
						
			return true;
		}
	}
	
	return false;
}

bool game::right(int pos, pair_char piece)
{
	int row = spaces[pos].first;
	int col = spaces[pos].second;
	pair_intv temp;	
	bool inside = puzzleWall(row, col+1);
	
	while(inside == true)
	{
		if(puzzle[row][col+1] != piece.first)break;
		
		temp.push_back(std::make_pair(row, col+1));
		col++;
		inside = puzzleWall(row, col+1);
	}
	;
	if(inside == true)
	{
		if(puzzle[row][col+1] == piece.second and !temp.empty())
		{
			int temp_size = temp.size();
			for(int r = 0; r < temp_size; r++)
				path.push_back(temp[r]);
					
			return true;
		}
	}
		
	return false;
}


bool game::l_downDiagonal(int pos, pair_char piece)
{
	int row = spaces[pos].first;
	int col = spaces[pos].second;
	pair_intv temp;	
	bool inside = puzzleWall(row+1, col-1);
	
	while(inside == true)
	{
		if(puzzle[row+1][col-1] != piece.first)break;
		
		temp.push_back(std::make_pair(row+1, col-1));
		col--;
		row++;
		inside = puzzleWall(row+1, col-1);
	}
	
	if(inside == true)
	{
		if(puzzle[row+1][col-1] == piece.second and !temp.empty())
		{
			int temp_size = temp.size();
			for(int r = 0; r < temp_size; r++)
				path.push_back(temp[r]);
								
			return true;
		}
	}
		
	return false;
}

bool game::l_upDiagonal(int pos, pair_char piece)
{
	int row = spaces[pos].first;
	int col = spaces[pos].second;
	pair_intv temp;
	bool inside = puzzleWall(row-1, col-1);
	
	while(inside == true)
	{
		if(puzzle[row-1][col-1] != piece.first)break;
		
		temp.push_back(std::make_pair(row-1, col-1));
		col--;
		row--;
		inside = puzzleWall(row-1, col-1);
	}
	
	if(inside == true)
	{
		if(puzzle[row-1][col-1] == piece.second and !temp.empty())
		{
			int temp_size = temp.size();
			for(int r = 0; r < temp_size; r++)
				path.push_back(temp[r]);
				
			return true;
		}
	}
	return false;
}

bool game::r_downDiagonal(int pos, pair_char piece)
{
	int row = spaces[pos].first;
	int col = spaces[pos].second;
	pair_intv temp;
	bool inside = puzzleWall(row+1, col+1);
	
	while(inside == true)
	{
		if(puzzle[row+1][col+1] != piece.first)break;
		
		temp.push_back(std::make_pair(row+1, col+1));
		col++;
		row++;
		inside = puzzleWall(row+1, col+1);
	}
	
	if(inside == true)
	{
		if( puzzle[row+1][col+1] == piece.second and !temp.empty())
		{
			int temp_size = temp.size();
			for(int r = 0; r < temp_size; r++)
				path.push_back(temp[r]);
				
			return true;
		}
	}
	
	return false;
}

bool game::r_upDiagonal(int pos, pair_char piece)
{
	int row = spaces[pos].first;
	int col = spaces[pos].second;
	pair_intv temp;
	bool inside = puzzleWall(row-1, col+1);
	
	while(inside == true)
	{
		if(puzzle[row-1][col+1] != piece.first)break;
		temp.push_back(std::make_pair(row-1, col+1));
		col++;
		row--;
		inside = puzzleWall(row-1, col+1);
	}
	
	if(inside == true)
	{
		if(puzzle[row-1][col+1] == piece.second and !temp.empty())
		{
			int temp_size = temp.size();
			for(int r = 0; r < temp_size; r++)
				path.push_back(temp[r]);
					
			return true;
		}
	}
	
	return false;
}


void game::ownPath(char piece)
{
	int size = path.size();
	for(int r = 0; r < size; r++)
		puzzle[path[r].first][path[r].second] = piece;
}

void game::results()
{
	int alg1_count = 0;
	int alg2_count = 0;
	
	for(int r = 0; r < rowcol_size; r++)
	{
		for(int c = 0; c < rowcol_size; c++)
		{
			if(puzzle[r][c] == 'b')
				alg1_count++;
			else if(puzzle[r][c] == 'w')
				alg2_count++;
		}
	}
	
	
	std::cout<<"Algorthm 1 score: "<<alg1_count<<"\n";
	std::cout<<"Algorthm 2 score: "<<alg2_count<<"\n";
	
	if(alg1_count > alg2_count)
		std::cout<<"Algorthm 1 won 🤸🤸🤸🤸🤸\n";
	else if(alg1_count < alg2_count)
		std::cout<<"Algorthm 2 won 🤸🤸🤸🤸🤸\n";
	else
		std::cout<<"Draw 🤼👊\n";
}


void game::printCurrentBoard()
{
	int row;
	int col;
	for(row = 0; row< rowcol_size; row++)
	{
		for(col = 0; col<rowcol_size; col++)
			std::cout<<" "<<puzzle[row][col];
		std::cout<<"\n";		
	}
}

