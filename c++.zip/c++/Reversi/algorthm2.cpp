#include "algorthm2.h"
#include "game.h"
#include<vector>
#include<iostream>
game g;

algorthm2::algorthm2(){}	

void algorthm2::getPosition()
{
	randomSpace rs;
	int pos = 0;
	
	if(g.EmptySpacesSize() != 0)
	{
		pair_intv temp(g.getEmptyspaces());

		while(!temp.empty())
		{
			if(g.pathSize() != 0)return;
			
			int newPos;
			std::pair<int,int> temp_pair;
			
			pos = rs.getRandPosition(temp.size());
			temp_pair.first = temp[pos].first;
			temp_pair.second = temp[pos].second;
			temp.erase(temp.begin() + pos);
			newPos = g.corrPosition(temp_pair);
			findpath(newPos);		
		}
		
		g.alg2MovesAvail(false);
	}
}
	
void algorthm2::findpath(int pos)
{	
	std::pair<char,char> pieces;
	pieces.first = 'b';
	pieces.second = 'w';
	
	g.down(pos, pieces);
	
	g.up(pos, pieces);
	
	g.left(pos, pieces);
	
	g.right(pos, pieces);
	
	g.l_downDiagonal(pos, pieces);
		
	g.l_upDiagonal(pos, pieces);
	
	g.r_downDiagonal(pos, pieces);
	
	g.r_upDiagonal(pos, pieces);
		
	if(g.pathSize() != 0)
	{
		g.fillFirstPos(pos);
		g.ownPath(pieces.second);
		g.removeUsedSpace(pos);
		g.alg2MovesAvail(true);
	}
}		
