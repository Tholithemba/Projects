#include "algorthm1.h"
#include "game.h"


algorthm1::algorthm1(){}

void algorthm1::setPosition()
{
	int size = g.EmptySpacesSize();
	max_size = 0;
	long_path_pos = 0;
	for(int r = 0; r < size; r++)
		findPath(r);

	if(!path2fill.empty())
	{
		longPath();
		g.ownPath('b');
		g.alg1MovesAvail(true);
		path2fill.clear();
		return;
	}
	
	g.alg1MovesAvail(false);
}


void algorthm1::findPath(int pos)
{
	std::pair<char,char> pieces;
	pieces.first = 'w';
	pieces.second = 'b';
	ch_vec temp;
	
	if(g.down(pos, pieces))
		temp.push_back('1');

	if(g.up(pos, pieces))
		temp.push_back('2');
	
	if(g.left(pos, pieces))
		temp.push_back('3');
	
	if(g.right(pos, pieces))
		temp.push_back('4');
	
	if(g.l_downDiagonal(pos, pieces))
		temp.push_back('5');
		
	if(g.l_upDiagonal(pos, pieces))
		temp.push_back('6');
	
	if(g.r_downDiagonal(pos, pieces))
		temp.push_back('7');
	
	if(g.r_upDiagonal(pos, pieces))
		temp.push_back('8');
		
	if(!temp.empty())
		pathOfBigLength(temp, pos);
}


void algorthm1::pathOfBigLength(ch_vec temp, int pos)
{
	
	int path_length = g.pathSize();

	if(path_length > max_size)
	{
		int temp_size = temp.size();
		path2fill.clear();
		for(int r = 0; r < temp_size; r++)
			path2fill.push_back(temp[r]);

		long_path_pos = pos;
		max_size = path_length;
	}
	g.clearPath();
}

void algorthm1::longPath()
{
	g.clearPath();
	std::pair<char,char> pieces;
	pieces.first = 'w';
	pieces.second = 'b';
	int path2f_length = path2fill.size();
	g.fillFirstPos(long_path_pos);

	for(int r = 0; r < path2f_length; r++)
	{
		switch(path2fill[r])
		{
			case '1': g.down(long_path_pos, pieces);
			break;
			
			case '2': g.up(long_path_pos, pieces);
			break;
			
			case '3': g.left(long_path_pos, pieces);
			break;
			
			case '4': g.right(long_path_pos, pieces);
			break;
			
			case '5': g.l_downDiagonal(long_path_pos, pieces);
			break;
				
			case '6': g.l_upDiagonal(long_path_pos, pieces);
			break;
			
			case '7': g.r_downDiagonal(long_path_pos, pieces);
			break;
			
			case '8': g.r_upDiagonal(long_path_pos, pieces);
			break;
			
			default: std::cout<<"error occurred!!!!! 🚫\n";
		}
	}
	
	g.removeUsedSpace(long_path_pos);
}
