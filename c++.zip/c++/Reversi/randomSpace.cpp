#include "randomSpace.h"
#include<ctime>
#include<cstdlib>

randomSpace::randomSpace()
{
	srand(time(0));
}

int randomSpace::getRandPosition(int bound)
{
	return (rand()% bound);
}
