#ifndef RANDOMSPACE_H
#define RANDOMSPACE_H

class randomSpace
{
	public:
		randomSpace();
		int getRandPosition(int bound);
};

#include "randomSpace.cpp"
#endif
