#include "random_access.h"
#include<ctime>
#include<cstdlib>

random_access::random_access()
{
	srand(time(0));
}

int random_access::random_position(int number_of_cards)
{
	return (rand() % number_of_cards);
}
