#ifndef TOPTEN_H
#define TOPTEN_H
#include<string>
#include<vector>

class topten
{
  public:
  		topten();
  		void start();
  		
  private:
  		void next_player();
  		void addToPlayers_stack(std::vector<std::pair<int, std::string>> temp);
  		void updatingTableSize(std::vector<std::pair<int, std::string>> temp);
  		void summation(std::pair<int, std::string> opened_card);
  		void addCardsToPlayedLast();
  		int points(std::vector<std::pair<int, std::string>> temp);
  		void updatePlayerCards(std::vector<std::pair<int, std::string>> &pl_cards, std::vector<std::pair<int, std::string>> temp);
  		void findOtherSum(std::vector<std::pair<int, std::string>> &pl_cards, std::vector<std::pair<int, std::string>> temp);
  		void results();
  		std::string card_type[4] = {"spade","club","diamond","heart"};
  		std::vector<std::pair<int, std::string>> cardlist;
  		void printScore(int player1_totalpoints, int player2_totalpoints);
		std::pair<int, std::string> cardInfo(int random_pos);
		int card_stack;
  		void card_position();
  		std::vector<std::pair<int, std::string>> open_table;
		std::vector<std::pair<int, std::string>> player_1Cards;
		std::vector<std::pair<int, std::string>> player_2Cards;
		void firstTime();
		bool firstCondition(int opened_card);
		void repeatOrNot(int sum, std::pair<int, std::string> opened_card);
		int doubleCheckSum(std::pair<int, std::string> opened_card);
		int minOf1_sumation(std::pair<int, std::string> opened_card);
		int minOf2_sumation(std::pair<int, std::string> opened_card);
		int minOf3_sumation(std::pair<int, std::string> opened_card);
		int minOf4_sumation(std::pair<int, std::string> opened_card);
  		bool player_1;
  		bool player_2;
  		const int MaxSum = 10;
  		bool repeat;
  		bool first_time;
};

#include "topten.cpp"
#endif
