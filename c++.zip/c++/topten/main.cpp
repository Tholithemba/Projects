#include "topten.h"


//main method
int main()
{
	topten tt;
	tt.start();//start the game

	return 0;
}
