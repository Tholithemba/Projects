#include "topten.h"

int main()
{
	topten tt;
	tt.start();

	return 0;
}



