#ifndef RANDOM_ACCESS_H
#define RANDOM_ACCESS_H

class random_access
{
	public:
		random_access();
		int random_position(int number_of_cards);
};
#include "random_access.cpp"
#endif
