#include "topten.h"
#include "random_access.h"
#include<iostream>
#include<bits/stdc++.h>


topten::topten()
{
	player_1 = true;
	player_2 = false;
	repeat = false;
	first_time = true;

	int r;
	int c;
	
	for(r = 1; r <= 10; r++)
		for(c = 0; c < 4; c++)
			cardlist.push_back(std::make_pair(r, card_type[c]));
	
	card_stack = cardlist.size();
}


void topten::start()
{
	while(card_stack  > 0)
	{	
		
		std::cout<<"card left: "<<card_stack<<std::endl;
		card_position();
		next_player();
		card_stack = cardlist.size();
	}
	results();
}

void topten::card_position()
{
	int number_of_cards = card_stack;
	random_access ra;

	int card_pos = ra.random_position(number_of_cards);

	std::pair<int, std::string> opened_card = cardInfo(card_pos);
	
	summation(opened_card);
}

void topten::summation(std::pair<int, std::string> opened_card)
{
	std::vector<std::pair<int, std::string>> temp;
	int sum = 0;
	
	firstTime();
	bool first_condition = firstCondition(opened_card.first);
	
	if(first_condition)
	{
		std::cout<<"first condition: card number: "<<opened_card.first<< " " <<opened_card.second<<std::endl;
		open_table.push_back(opened_card);
		repeat = false;
	}
	else
	{
		std::cout<<"not first condition: card number: "<<opened_card.first<< " " <<opened_card.second<<std::endl;
		if(opened_card.first != MaxSum)
		{
			sum = doubleCheckSum(opened_card);
		}
		else if(opened_card.first == MaxSum)
		{
			sum = opened_card.first;
			
			if(player_1)
			{
				player_1Cards.push_back(opened_card);
			}
			else
			{
				player_2Cards.push_back(opened_card);
			}
		}		
		repeatOrNot(sum, opened_card);
	}
}



bool topten::firstCondition(int opened_card)
{
	int open_table_size = open_table.size();
	return first_time == true and open_table_size == 0 and opened_card != MaxSum;
}

void topten::firstTime()
{
	std::pair<int, std::string> temp_pair;
	int stack_size;
	std::cout<<"first time \n";
	if(!first_time)
	{
		if(player_1)
		{
			stack_size = player_1Cards.size();
			if(stack_size != 0)
			{
				temp_pair = player_1Cards[stack_size - 1];
				open_table.push_back(temp_pair);
			}
		}
		else
		{
			stack_size = player_2Cards.size();
			if(stack_size != 0)
			{
				temp_pair = player_2Cards[stack_size - 1];
				open_table.push_back(temp_pair);
			}
		}
	}
}

void topten::repeatOrNot(int sum, std::pair<int, std::string> opened_card)
{
	
	if(sum == MaxSum)
	{
		std::cout<<"repeat true**************** \n";
		repeat = true;
	}
	else
	{
		open_table.push_back(opened_card);
		std::cout<<"repeat false**************** \n";
		repeat = false;
	}
}

int topten::minOf1_sumation(std::pair<int, std::string> opened_card)
{
	std::vector<std::pair<int, std::string>> temp;
	int sum=0;
	int r;
	int size;
	size = open_table.size();
	std::cout<<"sum 1 inside table size: "<<size<<std::endl;
	for(int i = 0; i < size; i++)
		std::cout<<" "<<open_table[i].first<<" "<<open_table[i].second;
	int g = 0;
	std::cout<<"\n";
	std::cout<<"card opened: "<<opened_card.first<<" "<<opened_card.second<<std::endl;
	for(r = 0; r < size; r++)
	{
		sum = opened_card.first + open_table[r].first;
		if(sum == MaxSum)
		{
			temp.push_back(open_table[r]);
			temp.push_back(opened_card);
			
			addToPlayers_stack(temp);
			return sum;
		}
	}
	
	return sum;
}

int topten::minOf2_sumation(std::pair<int, std::string> opened_card)
{
	std::vector<std::pair<int, std::string>> temp;
	
	int r;
	int size;
	int c;
	int sum = 0;
	size = open_table.size();
	std::cout<<"sum 2 inside table size: "<<size<<std::endl;
	for(int i = 0; i < size; i++)
		std::cout<<" "<<open_table[i].first<<" "<<open_table[i].second;
	
	std::cout<<"\n";
	std::cout<<"card opened: "<<opened_card.first<<" "<<opened_card.second<<std::endl;
	for(r = 0; r < size - 1; r++)
	{
		for(c = r + 1; c < size; c++)
		{
			sum = opened_card.first + open_table[r].first + open_table[c].first;

			if(sum == MaxSum)
			{
				temp.push_back(open_table[r]);
				temp.push_back(open_table[c]);
				temp.push_back(opened_card);
				
				addToPlayers_stack(temp);
				return sum;
			}
		}
	}
	return sum;
}


int topten::minOf3_sumation(std::pair<int, std::string> opened_card)
{
	std::vector<std::pair<int, std::string>> temp;
	int sum = 0;
	int r, size;
	size = open_table.size();
	int c, d;
	std::cout<<"sum 3 inside table size: "<<size<<std::endl;
	for(int i = 0; i < size; i++)
		std::cout<<" "<<open_table[i].first<<" "<<open_table[i].second;
	
	std::cout<<"\n";
	std::cout<<"card opened: "<<opened_card.first<<" "<<opened_card.second<<std::endl;
	for(r = 0; r < size - 2; r++)
	{
		for(c = r + 1; c < size - 1; c++)
		{
			for(d = c + 1; d < size; d++)
			{
				sum = opened_card.first + open_table[r].first + open_table[c].first + open_table[d].first;
				if(sum == MaxSum)
				{
					temp.push_back(open_table[r]);
					temp.push_back(open_table[c]);
					temp.push_back(open_table[d]);
					temp.push_back(opened_card);
					addToPlayers_stack(temp);
					return sum;
				}
			}
		}
	}
	return sum;	
}


int topten::minOf4_sumation(std::pair<int, std::string> opened_card)
{
	std::vector<std::pair<int, std::string>> temp;
	int sum = 0;
	int r, size;
	size = open_table.size();
	int c, d, e;
	std::cout<<"sum 3 inside table size: "<<size<<std::endl;
	for(r = 0; r < size; r++)
		std::cout<<" "<<open_table[r].first<<" "<<open_table[r].second;
	
	std::cout<<"\n";
	std::cout<<"card opened: "<<opened_card.first<<" "<<opened_card.second<<std::endl;
	for(r = 0; r < size - 3; r++)
	{
		for(c = r + 1; c < size - 2; c++)
		{
			for(d = c + 1; d < size - 1; d++)
			{
				for(e = d + 1; e < size; e++)
				{
					sum = opened_card.first + open_table[r].first + open_table[c].first + open_table[d].first + open_table[e].first;

					if(sum == MaxSum)
					{
						temp.push_back(open_table[r]);
						temp.push_back(open_table[c]);
						temp.push_back(open_table[d]);
						temp.push_back(open_table[e]);
						temp.push_back(opened_card);
						
						addToPlayers_stack(temp);
						return sum;
					}
				}
			}
		}
	}
	return sum;
}

int topten::doubleCheckSum(std::pair<int,std::string> opened_card)
{
	int sum = 0;
	int open_table_size = open_table.size();
	
	sum = minOf1_sumation(opened_card);
	if(sum != MaxSum and open_table_size > 1)
	{
		sum = minOf2_sumation(opened_card);
		std::cout<<"sum 2: "<<sum<<" \n";
		if(sum != MaxSum and open_table_size > 2)
		{
			sum = minOf3_sumation(opened_card);
			std::cout<<"sum 3: "<<sum<<" \n";
			if(sum != MaxSum and open_table_size > 3)
				sum = minOf4_sumation(opened_card);
		}
	}
	return sum;
}


void topten::addToPlayers_stack(std::vector<std::pair<int, std::string>> temp)
{
	std::sort(temp.begin(), temp.end());
	std::reverse(temp.begin(), temp.end());
	
	updatingTableSize(temp);	
	
	if(player_1)
	{
		updatePlayerCards(player_1Cards, temp);
		findOtherSum(player_2Cards, temp);
	}
	else
	{
		updatePlayerCards(player_2Cards, temp);
		findOtherSum(player_1Cards, temp);
	}
}

void topten::updatePlayerCards(std::vector<std::pair<int, std::string>> &pl_cards, std::vector<std::pair<int, std::string>> temp)
{
	int r, temp_size;
	temp_size = temp.size();
	
	for(r = 0; r < temp_size; r++)
			pl_cards.push_back(temp[r]);	
}

void topten::findOtherSum(std::vector<std::pair<int, std::string>> &pl_cards, std::vector<std::pair<int, std::string>> temp)
{	
	int r, temp_size, pl_cards_size, open_table_size;
	temp_size = temp.size();
	open_table_size = open_table.size();
	pl_cards_size = pl_cards.size();
	
	for(r = 0; r < temp_size; r++)
	{
		if(pl_cards_size != 0)
		{
			if(temp[r] == pl_cards[pl_cards_size -1] )
			{
				pl_cards.pop_back();
				if(open_table_size != 0)
					doubleCheckSum(pl_cards[pl_cards_size -1]);
			}
		}
	}
}


void topten::updatingTableSize(std::vector<std::pair<int, std::string>> temp)
{
	int r, c;
	int temp_size = temp.size();
	int open_table_size = open_table.size();
	std::cout<<"table size before update: "<<open_table_size<<std::endl;
	for(int i = 0; i < open_table_size; i++)
		std::cout<<"open_table["<<i<<"]: "<<open_table[i].first<<" "<<open_table[i].second<<std::endl;
		
	for(int i = 0; i < temp_size; i++)
		std::cout<<"temp["<<i<<"]: "<<temp[i].first<<" "<<temp[i].second<<std::endl;
		
	for(r = 0; r< open_table_size; r++)
	{
		for(c = 0; c < temp_size; c++)
		{
			if(open_table[r] ==  temp[c])
			{
				open_table.erase(open_table.begin()+r);
				open_table_size = open_table.size();
				r = r - 2;
				break;
			}
		}
		if(r < -1)r = -1;
	}
			
	
	open_table_size = open_table.size();
	std::cout<<"table size atfer update: "<<open_table_size<<std::endl;
	for(int i = 0; i < open_table_size; i++)
		std::cout<<"open_table["<<i<<"]: "<<open_table[i].first<<" "<<open_table[i].second<<std::endl;
		
	for(int i = 0; i < temp_size; i++)
		std::cout<<"temp["<<i<<"]: "<<temp[i].first<<" "<<temp[i].second<<std::endl;
}

void topten::results()
{
	int r;
	int player1Card_size;
	int player2Card_size;
	int open_table_size;
	
	player1Card_size = player_1Cards.size();
	player2Card_size = player_2Cards.size();
	open_table_size = open_table.size();
	
	std::cout<<"Player 1 cards in total: "<<player1Card_size<< "\n ";
	std::cout<<"Player 2 cards in total: "<<player2Card_size<< "\n ";
	std::cout<<"cardlist left in total: "<<cardlist.size()<< "\n ";
	std::cout<<"open table cards in total: "<<open_table_size<< "\n ";
	
	std::cout<<"open table cards \n";
	for(r = 0; r < open_table_size; r++)
		std::cout<<open_table[r].first<<" "<<open_table[r].second<<std::endl;
		
	addCardsToPlayedLast();
	
	player1Card_size = player_1Cards.size();
	player2Card_size = player_2Cards.size();
	open_table_size = open_table.size();
	
	std::cout<<"Player 1 cards \n";
	for(r = 0; r < player1Card_size; r++)
		std::cout<<player_1Cards[r].first<<" "<<player_1Cards[r].second<<std::endl;
	
	std::cout<<"Player 2 cards \n";
	for(r = 0; r < player2Card_size; r++)
		std::cout<<player_2Cards[r].first<<" "<<player_2Cards[r].second<<std::endl;

	int player1_totalpoints = points(player_1Cards);
	int player2_totalpoints = points(player_2Cards);
	
	printScore(player1_totalpoints, player2_totalpoints);
}

void topten::printScore(int player1_totalpoints, int player2_totalpoints)
{
	if(player1_totalpoints > player2_totalpoints)
	{
		std::cout<<"Player 1 score: "<<player1_totalpoints<<" Won🤸🤸🤸🤸 \n";
		std::cout<<"Player 2 score: "<<player2_totalpoints<<" lost🤔 \n";
	}
	else
	{
		std::cout<<"Player 2 score: "<<player2_totalpoints<<" Won🤸🤸🤸🤸 \n";
		std::cout<<"Player 1 score: "<<player1_totalpoints<<" lost🤔 \n";
	}
}

void topten::addCardsToPlayedLast()
{
	int r;
	int open_table_size = open_table.size();
	
	if((player_1 and repeat) or (player_2 and !repeat))
	{
		for(r = 0; r < open_table_size; r++)
			player_1Cards.push_back(open_table[r]);
	}
	else
	{
		for(r = 0; r < open_table_size; r++)
			player_2Cards.push_back(open_table[r]);	
	}
}

int topten::points(std::vector<std::pair<int, std::string>> temp)
{
	int totalpoints = 0, r;
	int temp_size = temp.size();
	int count_spade = 0;
	
	if(temp_size != 0)
	{
		for(r = 0; r <temp_size; r++)
		{
			if(temp[r].first == 1)
			{
				totalpoints += 1;
			}
			else if(temp[r].first == 2 and temp[r].second == "spade")
			{
				totalpoints += 1;
			}
			else if(temp[r].first == 10 and temp[r].second == "diamond")
			{
				totalpoints += 2;
			}
			
			if(temp[r].second == "spade")
				count_spade++;
		}
	}
	
	if(count_spade == 5)
		totalpoints +=1;
	else if(count_spade > 5)
		totalpoints +=2;
	
	if(temp_size == 20)
		totalpoints +=1;
	else if(temp_size > 20)
		totalpoints +=2;
	
	return totalpoints;
}


std::pair<int, std::string> topten::cardInfo(int random_pos)
{
	std::pair<int, std::string> card;
	card = cardlist[random_pos];
	cardlist.erase(cardlist.begin() + random_pos);
	card_stack = cardlist.size();
	return card;
}

void topten::next_player()
{
	if(player_1 and !repeat)
	{
		std::cout<<"player 1***************\n";
		player_1 = false;
		player_2 = true; 
	}
	else if(player_2 and !repeat)
	{
		std::cout<<"player 2*************** \n";
		player_1 = true;
		player_2 = false; 	
	}
	else if(player_1 and repeat)
	{
		std::cout<<"player 1 repeat*************** \n";
		player_1 = true;
		player_2 = false; 	
	}
	else if(player_2 and repeat)
	{
		std::cout<<"player 2 repeat*************** \n";
		player_1 = false;
		player_2 = true;
	}
}
