#include "game.h"
#include "randomAccess.h"
#include<vector>
#include<iostream>

//constructor
game::game()
{
	/*randomAccess ra;
	int start = ra.*/
	computer = false;
	human = true;
	game_over = false;
	init_count = 0;

	initializePuzzle();
	initializePosition();
}

void game::play()
{
	int count = 0;
	while(!unvisited_pos.empty())
	{
		
		lookPosition();
		if(game_over)return;
		printResults();
		
		nextPlayer();
		count++;
	}
	
	if(!game_over and unvisited_pos.empty())
		std::cout<<"draw 🤼\n";
}


void game::lookPosition()
{
	int row; 
	int col;
	char placement = ' ';
	bool matched;
	
	if(init_count < 3)
	{
		rowColRandom(row, col);
		init_count++;
	}
	else
	{
		if(human)
		{
			if(check(human_lp.first, human_lp.second, x))return;
			if(checkWinLoose(computer_lp.first, computer_lp.second, o))return;
		}
		else
		{	
			if(check(computer_lp.first, computer_lp.second, o))return;
			if(checkWinLoose(human_lp.first, human_lp.second, x))return;
		}
		
		rowColRandom(row, col);
	}
	
	placeinPosition(row, col);
}

bool game::check(int row, int col, char placement)
{
	if(checkWinLoose(row, col, placement))
	{
		gameOver();
		return true;
	}
	
	return false;
}


bool game::checkWinLoose(int row, int col, char placement)
{
	bool found = true;
	bool exist;
	
	if(diagonal(row, col))
	{
		if(row == 1 and col == 1)
		{
			if(leftDiagonal(placement))return found;			
			if(rightDiagonal(placement))return found;
		}
		else if(row == col)
		{
			if(rightDiagonal(placement))return found;
		}
		else
		{
			if(leftDiagonal(placement))return found;
		}
	}
	
	if(vertical(placement, col))return found;	
	if(horizontal(placement, row))return found;
	
	return false;
}

void game::rowColRandom(int &row, int &col)
{
	randomAccess ra;
	int rand_num;
	rand_num = ra.randomPosition(unvisited_pos.size());
	row = unvisited_pos[rand_num].first;
	col = unvisited_pos[rand_num].second;
}


void game::placeinPosition(int row, int col)
{
	int r;
	if(human)
	{
		puzzle[row][col] = x;
		human_lp.first = row;
		human_lp.second = col;	
	}
	else
	{
		puzzle[row][col] = o;
		computer_lp.first = row;
		computer_lp.second = col;
	}
	
	for(r = 0; r < unvisited_pos.size(); r++)
		if(unvisited_pos[r].first == row and unvisited_pos[r].second == col)
			unvisited_pos.erase(unvisited_pos.begin()+r);
}

bool game::diagonal(int row ,int col)
{
	return ((row==col) or (row-col==2) or (row-col==-2));
}


bool game::vertical(char placement, int col)
{
 	int row;
 	int count = 0;
 	bool match = false;
 	
 	for(row = 0; row< size; row++)
 	{
 		if(puzzle[row][col] == placement)
 			count++;
 	}
 	
 	if(count == 2)
 	{
	 	for(row = 0; row< size; row++)
	 	{
	 		if(puzzle[row][col] == 'z')
	 		{
	 			placeinPosition(row, col);
	 			return true;
	 		}
	 	}
 	}
 	
 	return match;
}

bool game::horizontal(char placement, int row)
{
 	int col;
 	int count = 0;
 	bool match = false;

 	for(col = 0; col< size; col++)
 	{
 		if(puzzle[row][col] == placement)
 			count++;
 	}
 	
 	if(count == 2)
 	{
	 	for(col = 0; col< size; col++)
	 	{
	 		if(puzzle[row][col] == 'z')
	 		{
	 			placeinPosition(row, col);
	 			return true;
	 		}
	 	}
 	}
 	
 	return match;
}


bool game::leftDiagonal(char placement)
{
 	int row = 0;
 	int col = 2;
 	int count = 0;
 	bool match = false;
 	
 	while(row < size)
 	{
 		if(puzzle[row][col] == placement)
 			count++;
 		col--;
 		row++;
 	}
 	row = 0;
 	col = 2;
 	if(count == 2)
 	{
	 	while(row < size)
	 	{
	 		if(puzzle[row][col] == 'z')
	 		{
	 			placeinPosition(row, col);
	 			return true;
	 		}
	 		
	 		col--;
	 		row++;
	 	}
 	}
 	
 	return match;
}

bool game::rightDiagonal(char placement)
{
 	int row = 0;
 	int col = 0;
 	int count = 0;
 	bool match = false;
 	
 	while(row < size)
 	{
 		if(puzzle[row][col] == placement)
 			count++;
 		col++;
 		row++;
 	}
 	row = 0;
 	col = 0; 	
 	if(count == 2)
 	{
	 	while(row < size)
	 	{
	 		if(puzzle[row][col] == 'z')
	 		{
	 			placeinPosition(row, col);
	 			return true;
	 		}
	 		
	 		col++;
	 		row++;
	 	}
 	}
 	
 	return match;
}

void game::gameOver()
{
	printResults();
	if(human)
		std::cout<<"human won 🤸🤸🤸🤸\n";
	else 
		std::cout<<"Computer won 🤸🤸🤸🤸\n";
	game_over = true;
}

void game::nextPlayer()
{
	if(human)
	{
		human = false;
		computer = true;
	}
	else
	{
		human = true;
		computer = false;
	}
}


void game::printResults()
{
	std::string blue_color = "\033[1;33m";
	std::cout<<blue_color;
	for(int r = 0; r < size; r++)
	{
		for(int c = 0; c < size; c++)
		{
			std::cout<<puzzle[r][c]<<" ";
		}
		std::cout<<"\n";
	}
	std::cout<<"************************************************\n";
	std::cout<<"\n";
}

void game::initializePuzzle()
{
	int row;
	int col;
	
	puzzle = new char*[size];
	
	for(row = 0; row < size; row++)
		puzzle[row] = new char[size];
	
	for(row = 0; row < size; row++)
		for(col = 0; col < size; col++)
			puzzle[row][col] = 'z';	
}

void game::initializePosition()
{
	int row;
	int col;
		
	for(row = 0; row < size; row++)
		for(col = 0; col < size; col++)
			unvisited_pos.push_back(std::make_pair(row , col));
}



