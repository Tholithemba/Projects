#include "game.h"
//program execution starts here
int main()
{
	game g;
	g.play();
	
	return 0;
}

