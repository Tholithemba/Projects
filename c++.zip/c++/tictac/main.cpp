#include<iostream>
#include "game.h"

void drawPuzzle(char** &puzzle);

int main()
{
	game g;
	g.play();
	
	return 0;
}

