#ifndef RANDOMACCESS_H
#define RANDOMACCESS_H

class randomAccess
{
	public:
		randomAccess();
		int randomPosition(int unvisited);
};

#include "randomAccess.cpp"
#endif
