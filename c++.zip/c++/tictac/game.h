#ifndef GAME_H
#define GAME_H
#include<vector>

class game
{
	public:
		game();
		void play();
		
	private:
		void printResults();
		void lookPosition();
		bool validPostion(int row, int col);
		void nextPlayer();
		bool vertical(char placement, int fixed);
		bool horizontal(char placement, int fixed);
		bool leftDiagonal(char placement);
		bool rightDiagonal(char placement);
		void rowColRandom(int &row, int &col);
		void setColRow(int &row, int &col);
		void placeinPosition(int row, int col);
		bool checkWinLoose(int row, int col, char placement);
		bool check(int row, int col, char placement);
		void gameOver();
		void initializePuzzle();
		void initializePosition();
		bool diagonal(int row ,int col);
		bool computer;
		bool human;
		bool game_over;
		std::vector<std::pair<int,int>> unvisited_pos;
		std::pair<int,int> human_lp;
		std::pair<int,int> computer_lp;
		char** puzzle;
		char const x = 'x';
		char const o = 'o';
		int const size = 3;
		int init_count;
};
#include "game.cpp"
#endif
