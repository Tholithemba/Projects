/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinic_management;

/**
 *
 * @author tholithemba
 */
public class PatientRegistration {
    
        private String dob;
        private static String id_no;
        private static String gender;
        private static String mob_number;
        private static String occupation;
        
        private static String line_1;
        private static String line_2 ;
        private static String line_3;
        private static String postal_code;
        private static String city ;
        private static String province;
    
        
        public void setPatientID(String set_id_no){
            id_no = set_id_no;
        }
        
        public String getPatientID(){
            return id_no;
        }


        public void setPatientDOB(String set_dob){
            this.dob = set_dob;
        }
        
        public String getPatientDOB(){
            return dob;
        }


        public void setPatientGender(String set_gender){
            gender = set_gender;
        }
        
        public String getPatientGender(){
            return gender;
        }

        public void setPatientMobileNo(String set_mobile_no){
            mob_number = set_mobile_no;
        }
        
        public String getPatientMobileNo(){
            return mob_number;
        }

        public void setPatientOccupation(String set_occup){
            occupation = set_occup;
        }
        
        public String getPatientOccupation(){
            return occupation;
        }

        public void setPatientAddress1(String set_addr1){
            line_1 = set_addr1;
        }
        
        public String getPatientAddress1(){
            return line_1;
        }

        public void setPatientAddress2(String set_addr2){
            line_2 = set_addr2;
        }
        
        public String getPatientAddress2(){
            return line_2;
        }


        public void setPatientAddress3(String set_addr3){
           line_3 = set_addr3;
        }
        
        public String getPatientAddress3(){
            return line_3;
        }

        public void setPatientPostalCode(String set_pcode){
            postal_code = set_pcode;
        }
        
        public String getPatientPostalCode(){
            return postal_code;
        }

        public void setPatientCity(String set_city){
            city = set_city;
        }
        
        public String getPatientCity(){
            return city;
        }

        public void setPatientProvince(String set_province){
           province = set_province;
        }
        
        public String getPatientProvince(){
            return province;
        }
}
