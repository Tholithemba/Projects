/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinic_management;

/**
 *
 * @author tholithemba
 */
public class UserRegistration {
    
    private static String firstname;
    private static String lastname;
    private static String username;
    private static String password;
    
    public void setFirstname(String set_firstname){
        firstname = set_firstname;
    }
    
    public String getFirstName(){
        return firstname;
    }
    
    public void setLastname(String set_lastname){
        lastname = set_lastname;
    }
    
    public String getLastname(){
        return lastname;
    }

    public void setUsername(String set_username){
        username = set_username;
    }
    
    public String getUsername(){
        return username;
    }
    
    public void setPassword(String set_password){
        password = set_password;
    }
  
    public String getPassword(){
        return password;
    }
}