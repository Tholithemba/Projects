/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinic_management;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author tholithemba
 */
public class UpdateDataFields {
    
    private String field_data;
    private static String heading_name;
    UserRegistration user_reg = new UserRegistration();
    GenerateRandomChar grc = new GenerateRandomChar();
   
    
    public void setFieldData(String set_field_data){
        this.field_data = set_field_data;
    }
    
    public String getFieldData(){
        return field_data;
    }
    
    public void setHeadingName(String set_head_name){
        heading_name = set_head_name;
    }
    
    public String getHeadingName(){
        return heading_name;
    }
    
    public String getDataTobeUpdated(String query_statement){

        PreparedStatement ps;
        ResultSet rs;
        
        try{
            ps = Connect2database.getConnection().prepareStatement(query_statement);
            ps.setString(1, user_reg.getUsername());
            
            rs = ps.executeQuery();
            
            if(rs.next())
               setFieldData(rs.getString(getHeadingName()));
            else
                setFieldData(null);

        } catch (SQLException ex) {
            Logger.getLogger(UpdateDataFields.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if(getHeadingName().equals("PASSWORD"))
            setFieldData("");

        
        return getFieldData();    
    }
    
    public boolean addUpdatedData(String query_statement){
        
        PreparedStatement ps;
        boolean update_succeed = false;
        
        String modified_data = getFieldData();
        if(getHeadingName().equals("PASSWORD"))
            modified_data = grc.passwordEncryption(modified_data);
        
     
        try{
            ps = Connect2database.getConnection().prepareStatement(query_statement);
            
            ps.setString(1, modified_data);
            ps.setString(2, user_reg.getUsername());
            
            if(ps.executeUpdate() > 0)
                update_succeed = true;
            
        } catch (SQLException ex) {
            Logger.getLogger(UpdateDataFields.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return update_succeed;
    }
}
