/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rdphouses;

/**
 *
 * @author tholithemba
 */
public class Registration {
    private String firstname;
    private String lastname;
    private String funderType;
    private String org_name;
    private String contact_no;
    private String email;
    private String status;
    private String treshold;
    private String amountpayed;
    private String addr1;
    private String addr2;
    private String addr3 = "";
    private String postal_code;
    private int admin_id;
    private String username;
    private String password;
    private String gender;
    private String ethinicity;
    private String date_of_birth;
    private String pref_communication_medium;
    private String proof_of_income_file;
    private String id_file;
    private String id_number;
    
    public Registration(){
    }
    
    public Registration(int id){
        this.admin_id = id;
    }
    
    public void setAdminID(int adm_id){
        this.admin_id = adm_id;
    }
    
    public int getAdminID(){
        return admin_id;
    }

    public void setFirstname(String f_name){
        this.firstname = f_name;
    }
    
    public String getFirstname(){
        return firstname;
    }
    
    public void setLastname(String l_name){
        this.lastname = l_name;
    }
    
    public String getLastname(){
        return lastname;
    }
    
    public void setUsername(String uname)
    {
        this.username = uname;
    }
    
    public String getUsername()
    {
        return username;
    }
      public void setPassword(String pword)
    {
        this.password = pword;
    }
    
    public String getPassword()
    {
        return password;
    }
    
    public void setFundertype(String set_type){
        this.funderType = set_type;
    }
    
    public String getFundertype(){
        return funderType;
    }
    
    public void setOrganisationName(String orgName){
        this.org_name = orgName;
    }
    
    public String getOrganisationName(){
        return org_name;
    }
    
    public void setContactNo(String cont_no){
        this.contact_no = cont_no;
    }
    
    public String getContactNo(){
        return contact_no;
    }
    
    public void setEmail(String set_email){
        this.email = set_email;
    }
    
    public String getEmail(){
        return email;
    }
    
    public void setStatus(String set_status){
        this.status = set_status;
    }
    
    public String getStatus(){
        return status;
    }
    
    public void setTreshold(String set_treshold){
        this.treshold = set_treshold;
    }
    
    public String getTreshold(){
        return treshold;
    }
 
    public void setAmountPayed(String set_amount){
        this.amountpayed = set_amount;
    }
    
    public String getAmountPayed(){
        return amountpayed;
    }
    
    public void setAddress1(String set_addr1){
        this.addr1 = set_addr1;
    }
    
    public String getAddress1(){
        return addr1;
    }
    
    public void setAddress2(String set_addr2){
        this.addr2 = set_addr2;
    }
    
    public String getAddress2(){
        return addr2;
    }
    
    public void setAddress3(String set_addr3){
        this.addr3 = set_addr3;
    }
    
    public String getAddress3(){
        return addr3;
    }
    
    public void setPostalCode(String p_code){
        this.postal_code = p_code;
    }
    
    public String getPostalCode(){
        return postal_code;
    }
    
    public void setGender(String set_gender){
        this.gender = set_gender;
    }
    
    public String getGender(){
        return gender;
    }
    
        public void setDOB(String dob){
        this.date_of_birth = dob;
    }
    
    public String getDOB(){
        return date_of_birth;
    }
    
    public void setEthinicity(String set_eth){
        this.ethinicity = set_eth;
    }
    
    public String getEthinicity(){
        return ethinicity;
    }
    
    public void setPrefCommMedium(String p_c_medium){
        this.pref_communication_medium = p_c_medium;
    }
    
    public String getPrefCommMedium(){
        return pref_communication_medium;
    }
    
    public void setProofOFIncomeFile(String pr_of_income_f){
        this.proof_of_income_file = pr_of_income_f;
    }
    
    public String getProofOFIncomeFile(){
        return proof_of_income_file;
    }
    
    public void setIDFile(String id_f){
        this.id_file = id_f;
    }
    
    public String getIDFile(){
        return id_file;
    }
    
    public void setIDNumber(String id_no){
        this.id_number = id_no;
    }
    
    public String getIDNumber(){
        return id_number;
    }
    
}
