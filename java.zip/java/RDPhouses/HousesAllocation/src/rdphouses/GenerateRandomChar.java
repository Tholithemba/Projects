/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rdphouses;

import java.util.Random;

/**
 *
 * @author tholithemba
 */
public class GenerateRandomChar {
    private final char[] char_password={'q','4','w','#','7','e','2','r','$',
        'r','t','y','&','5','u','i','o','?','0','p','a','*','9','s','!',
        'd','f','1','g','h','j','k','8','l','z','x','@','c','3','v','%','b',
        'n','6','_','m'};
    
    private final char[] char_username={'q','w','e','r','t','y','u','i','o'
    ,'p','a','s','d','f','g','h','j','k','l','z','x','c','v','b','n','m'};
    Random rand = new Random();
    
    public String generateUsername()
    {
        int random;
        String random_username ="";
        int r;
        int char_username_size = char_username.length;
        int size = 10;
        for(r = 0; r < size; r++){
            random = rand.nextInt(char_username_size);
            random_username = random_username+char_username[random];
        }
                
        return random_username;
    }
    
    public String generatePassword()
    {
        int random;
        String random_password ="";
        int char_pass_size = char_password.length;
        int r;
        int size = 10;
        for(r = 0; r < size; r++){
            random = rand.nextInt(char_pass_size);
            random_password = random_password+char_password[random];
        }
        
        return random_password;
    }
}
